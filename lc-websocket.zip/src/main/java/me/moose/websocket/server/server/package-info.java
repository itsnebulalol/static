package me.moose.websocket.server.server;

/*
*
* package me.moose.websocket.server.server will hold anything to do with with the server connection of the websocket.
*
*/