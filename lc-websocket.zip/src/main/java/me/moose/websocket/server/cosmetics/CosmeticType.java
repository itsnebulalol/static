package me.moose.websocket.server.cosmetics;

public enum CosmeticType {
    CAPE,
    HAT,
    MASK,
    BANDANNAS,
    BODYWEAR,
    DRAGON_WINGS,
}
