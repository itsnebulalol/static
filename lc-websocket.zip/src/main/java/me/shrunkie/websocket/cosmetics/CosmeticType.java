package me.shrunkie.websocket.cosmetics;

public enum CosmeticType {
    CAPE,
    HAT,
    MASK,
    BANDANNAS,
    BODYWEAR,
    DRAGON_WINGS,
}
